# scripts
▶️ Bash / PowerShell and Python scripts for various projects
