# cloudgeeks.ca

# docker-django-redis-celery-no-supervisor

Docker Django Redis Celery (No Supervisor)

## Getting Started
This project works on Python 3+ and Django 2+.
Simply, run the following command:
```
docker-compose up --build
```