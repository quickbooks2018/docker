# cloudgeeks.ca

# docker-django-redis-celery-nginx-supervisor

Docker Nginx Django Redis Celery Supervisor

## Getting Started
This project works on Python 3+ and Django 2+.
Simply, run the following command:
```
docker-compose up -d --build
```
